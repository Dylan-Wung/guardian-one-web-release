#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Scan Worker – Phase 1  (v1.3.0)
Author: Dylan 
Last Modified: 2025-08-09

Changelog
- v1.3.0
  * 新增掃描模式：host_subnet（自動偵測本機預設路由介面之 IPv4 CIDR）
    - 解析 `ip -4 route show default` 取得介面，再以 `ip -4 addr show dev <iface>` 取 CIDR
    - 僅允許 RFC1918 私網；可用環境變數覆寫：HOST_ADDR / HOST_NETMASK
  * 保留 v1.2.1 的「只輸出有開放連接埠的主機」行為與黑名單合併
- v1.2.1
  * results.json / API 只輸出有開放連接埠的主機（移除空 ports 結果）
- v1.2.0
  * start_scan(profile_name, mode, cidr, deny_ips_override, ack_risk)
    - mode: "yaml_list" | "cidr"
    - cidr: 需為 RFC1918；"cidr" 模式需 ack_risk=True
- v1.1.1
  * 只掃描 ap_list.yaml 的私網 IP；nmap greppable 摘要、job 產物；高風險埠告警節流
"""

import os
import re
import json
import time
import shutil
import socket
import ipaddress
import threading
import subprocess
from datetime import datetime
from pathlib import Path

# 專案路徑
BASE_DIR = Path(__file__).resolve().parent
SCAN_DIR = BASE_DIR / "scan_jobs"
SCAN_DIR.mkdir(exist_ok=True)

# 檔案路徑
AP_YAML = BASE_DIR / "ap_list.yaml"
SCAN_YAML = BASE_DIR / "scan_config.yaml"

# 讀 .env
from dotenv import load_dotenv
load_dotenv(BASE_DIR / ".env")

DEFAULT_PROFILE = os.getenv("SCAN_DEFAULT_PROFILE", "light")
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

# 可選覆寫本機子網的環境變數（若系統指令解析失敗時使用）
HOST_ADDR = os.getenv("HOST_ADDR")        # 例：10.10.100.14
HOST_NETMASK = os.getenv("HOST_NETMASK")  # 例：255.255.255.0

# 高風險埠告警節流狀態檔
ALERT_STATE_FILE = SCAN_DIR / ".alert_state.json"

# 私有網段（RFC1918）
PRIVATE_NETS = [
    ("10.0.0.0", 8),
    ("172.16.0.0", 12),
    ("192.168.0.0", 16),
]

# 依賴
try:
    import yaml
except Exception:
    print("請先於 venv 安裝 pyyaml：pip install pyyaml")
    raise

# -------------------- 工具函式 --------------------
def is_valid_ipv4(ip: str) -> bool:
    try:
        socket.inet_aton(str(ip).strip())
        return True
    except OSError:
        return False

def ip_in_private(ip: str) -> bool:
    """檢查單一 IPv4 是否位於 RFC1918 私有網段"""
    if not is_valid_ipv4(ip):
        return False
    ip_int = int.from_bytes(socket.inet_aton(ip), 'big')
    for net, cidr in PRIVATE_NETS:
        net_int = int.from_bytes(socket.inet_aton(net), 'big')
        mask = (0xFFFFFFFF << (32 - cidr)) & 0xFFFFFFFF
        if (ip_int & mask) == (net_int & mask):
            return True
    return False

def cidr_is_private(cidr: str) -> bool:
    """CIDR 是否位於 RFC1918"""
    try:
        net = ipaddress.ip_network(cidr, strict=False)
        return any(str(net.network_address).startswith(prefix) for prefix in (
            "10.", "192.168.", "172.16.", "172.17.", "172.18.", "172.19.",
            "172.20.", "172.21.", "172.22.", "172.23.", "172.24.", "172.25.",
            "172.26.", "172.27.", "172.28.", "172.29.", "172.30.", "172.31."
        ))
    except Exception:
        return False

def iter_hosts_from_cidr(cidr: str, max_hosts: int) -> list:
    """將 CIDR 展開為 host 清單（排除網路/廣播），並限制筆數"""
    try:
        net = ipaddress.ip_network(cidr, strict=False)
    except Exception:
        return []
    hosts = []
    for ip in net.hosts():
        if len(hosts) >= max_hosts:
            break
        hosts.append(str(ip))
    return hosts

def load_yaml(path: Path):
    return yaml.safe_load(path.read_text(encoding="utf-8")) if path.exists() else {}

def netmask_to_prefix(netmask: str) -> int:
    """把 255.255.255.0 轉成 24；非法傳入回傳 -1"""
    try:
        return ipaddress.IPv4Network(f"0.0.0.0/{netmask}").prefixlen
    except Exception:
        return -1

def detect_host_cidr() -> str | None:
    """
    取得本機預設路由介面 IPv4 CIDR：
    1) 讀環境變數 HOST_ADDR + HOST_NETMASK（若有且有效）
    2) 以 `ip -4 route show default` 找 iface
       再 `ip -4 addr show dev <iface>` 解析 "inet X/Y"
    """
    # env override
    if HOST_ADDR and HOST_NETMASK and is_valid_ipv4(HOST_ADDR):
        pfx = netmask_to_prefix(HOST_NETMASK)
        if pfx > 0:
            return f"{HOST_ADDR}/{pfx}"
    # system detection
    try:
        r = subprocess.run(["ip", "-4", "route", "show", "default"],
                           stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
        line = (r.stdout or "").splitlines()[0] if r.returncode == 0 else ""
        # ex: "default via 10.10.100.1 dev eth0 proto dhcp src 10.10.100.14 metric 100"
        m = re.search(r"\bdev\s+(\S+)", line)
        iface = m.group(1) if m else None
        if not iface:
            return None
        r2 = subprocess.run(["ip", "-4", "addr", "show", "dev", iface],
                            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
        # ex: "inet 10.10.100.14/24 brd 10.10.100.255 scope global dynamic eth0"
        m2 = re.search(r"\binet\s+([0-9.]+\/\d+)\b", r2.stdout or "")
        return m2.group(1) if m2 else None
    except Exception:
        return None

# -------------------- 目標收集 --------------------
def collect_targets_from_locations(ap_yaml: Path, deny_ips: list, max_hosts: int) -> list:
    """從 ap_list.yaml 收集私有 IP 目標，套用黑名單與上限"""
    cfg = load_yaml(ap_yaml)
    locs = cfg.get("locations", {})
    ips, seen = [], set()
    deny = {ip.strip() for ip in (deny_ips or []) if is_valid_ipv4(ip)}
    for _, cats in locs.items():
        if not isinstance(cats, dict):
            continue
        for _, devices in cats.items():
            if not isinstance(devices, list):
                continue
            for d in devices:
                ip = str(d.get("ip", "")).strip()
                if not ip or ip in seen or ip in deny:
                    continue
                if not ip_in_private(ip):
                    continue
                seen.add(ip)
                ips.append(ip)
                if len(ips) >= max_hosts:
                    return ips
    return ips

def collect_targets_from_cidr(cidr: str, deny_ips: list, max_hosts: int) -> list:
    """從 CIDR 展開目標，僅允許 RFC1918，套用黑名單與上限"""
    if not cidr_is_private(cidr):
        return []
    deny = {ip.strip() for ip in (deny_ips or []) if is_valid_ipv4(ip)}
    hosts = []
    for ip in iter_hosts_from_cidr(cidr, max_hosts * 2):  # 多抓一些再濾
        if ip in deny:
            continue
        if not ip_in_private(ip):
            continue
        hosts.append(ip)
        if len(hosts) >= max_hosts:
            break
    return hosts

# -------------------- nmap 執行與解析 --------------------
GREPPABLE_PORTS_RE = re.compile(r"Ports: (.*)")

def parse_greppable_line(line: str):
    # 例："Host: 10.10.100.7 ()  Ports: 22/open/tcp//ssh///, 80/open/tcp//http///"
    m = GREPPABLE_PORTS_RE.search(line)
    if not m:
        return []
    ports_seg = m.group(1)
    results = []
    for part in ports_seg.split(','):
        part = part.strip()
        try:
            port, state, proto, *_rest = part.split('/')
            if state != 'open':
                continue
            results.append({"port": int(port), "proto": proto})
        except Exception:
            continue
    return results

def run_nmap_chunk(targets: list, profile: dict, out_path: Path):
    args = ["nmap", "-oG", str(out_path)]
    # Profile args
    args += profile.get("args", [])
    top_ports = profile.get("top_ports")
    if top_ports:
        args += ["--top-ports", str(top_ports)]
    # 禁用 -sS（如需開啟，另行規劃 capabilities）
    args += targets
    proc = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    return proc.returncode, proc.stdout

# -------------------- Telegram 告警（節流） --------------------
import requests

def _load_alert_state():
    if ALERT_STATE_FILE.exists():
        try:
            return json.loads(ALERT_STATE_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}

def _save_alert_state(state: dict):
    ALERT_STATE_FILE.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")

def send_telegram_alert(high_risk_items: list, throttle_seconds: int):
    if not (TELEGRAM_TOKEN and TELEGRAM_CHAT_ID and high_risk_items):
        return
    state = _load_alert_state()
    now = int(time.time())
    last = int(state.get("last_ts", 0))
    if now - last < throttle_seconds:
        return  # 節流視窗內，略過
    lines = [
        "<b>nmap 掃描高風險開放埠</b>",
        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "\n".join(high_risk_items[:50])
    ]
    try:
        requests.post(
            f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage",
            data={"chat_id": TELEGRAM_CHAT_ID, "text": "\n".join(lines), "parse_mode": "HTML"},
            timeout=30
        ).raise_for_status()
        state["last_ts"] = now
        _save_alert_state(state)
    except Exception:
        pass

# -------------------- Job 執行器 --------------------
class JobState:
    def __init__(self, job_id: str, profile: str, targets: list):
        self.job_id = job_id
        self.profile = profile
        self.targets = targets
        self.state = "queued"  # queued|running|succeeded|failed|canceled
        self.started_at = None
        self.finished_at = None
        self.progress_done = 0
        self.progress_total = len(targets)
        self.summary = {"hosts": len(targets), "duration_sec": 0, "open_ports": 0}
        self.dir = SCAN_DIR / job_id
        self.dir.mkdir(parents=True, exist_ok=True)
        self._persist()

    def _persist(self):
        (self.dir / "status.json").write_text(json.dumps({
            "job_id": self.job_id,
            "state": self.state,
            "profile": self.profile,
            "progress": {"done": self.progress_done, "total": self.progress_total, "eta_sec": None},
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "summary": self.summary
        }, ensure_ascii=False, indent=2), encoding="utf-8")

    def tick(self, inc=1):
        self.progress_done += inc
        self._persist()

    def set_state(self, state: str):
        self.state = state
        if state == "running":
            self.started_at = datetime.utcnow().isoformat() + "Z"
        if state in ("succeeded", "failed", "canceled"):
            self.finished_at = datetime.utcnow().isoformat() + "Z"
        self._persist()

class ScanManager:
    def __init__(self):
        self.lock = threading.Lock()
        self.jobs = {}

    def _merge_deny(self, cfg: dict, override: list) -> list:
        cfg_deny = cfg.get("targets", {}).get("deny_ips", []) or []
        ov_deny = override or []
        merged = sorted({ip.strip() for ip in (cfg_deny + ov_deny) if is_valid_ipv4(ip)})
        return merged

    def start_scan(
        self,
        profile_name: str = None,
        mode: str = None,
        cidr: str = None,
        deny_ips_override: list = None,
        ack_risk: bool = False
    ) -> str:
        """
        建立掃描 Job（雙/三模式）：
          - mode="yaml_list": 只掃 ap_list.yaml 內的私網 IP
          - mode="cidr": 掃傳入的 RFC1918 CIDR（需 ack_risk=True）
          - mode="host_subnet": 掃描本機（Web 服務所在主機）的預設路由子網（RFC1918）
        """
        cfg = load_yaml(SCAN_YAML)
        if not cfg:
            raise RuntimeError("找不到 scan_config.yaml 或內容為空")

        profile_name = profile_name or DEFAULT_PROFILE
        profile = cfg.get("scan_profiles", {}).get(profile_name)
        if not profile:
            raise RuntimeError(f"未知的 profile: {profile_name}")

        limits = cfg.get("limits", {})
        max_hosts = int(limits.get("max_hosts_per_job", 256))

        # 合併黑名單
        deny_merged = self._merge_deny(cfg, deny_ips_override)

        # 目標來源
        targets: list
        mode = (mode or "yaml_list").strip().lower()

        if mode == "cidr":
            if not ack_risk:
                raise RuntimeError("CIDR 掃描需要 ack_risk=true")
            if not cidr:
                raise RuntimeError("CIDR 模式需要提供 cidr 參數")
            if not cidr_is_private(cidr):
                raise RuntimeError("只允許 RFC1918 私有網段 CIDR")
            targets = collect_targets_from_cidr(cidr, deny_merged, max_hosts)

        elif mode == "host_subnet":
            # 自動偵測本機 CIDR
            cidr_auto = detect_host_cidr()
            if not cidr_auto:
                raise RuntimeError("無法偵測本機子網（可用環境變數 HOST_ADDR / HOST_NETMASK 覆寫）")
            # 將 host /prefix 轉換為「該子網」網段
            try:
                net = ipaddress.ip_network(cidr_auto, strict=False)
                cidr_net = f"{net.network_address}/{net.prefixlen}"
            except Exception:
                raise RuntimeError(f"本機 CIDR 解析失敗：{cidr_auto}")
            if not cidr_is_private(cidr_net):
                raise RuntimeError(f"主機所在網段非 RFC1918：{cidr_net}")
            targets = collect_targets_from_cidr(cidr_net, deny_merged, max_hosts)

        else:  # yaml_list (default)
            targets = collect_targets_from_locations(AP_YAML, deny_merged, max_hosts)

        job_id = datetime.utcnow().strftime("SCAN-%Y%m%d-%H%M%S")
        job = JobState(job_id, profile_name, targets)
        self.jobs[job_id] = job
        t = threading.Thread(target=self._run_job, args=(job, profile, cfg), daemon=True)
        t.start()
        return job_id

    def _run_job(self, job: JobState, profile: dict, cfg: dict):
        if shutil.which("nmap") is None:
            job.set_state("failed")
            (job.dir / "error.log").write_text("nmap 未安裝，請先安裝：sudo apt-get install nmap\n", encoding="utf-8")
            return

        job.set_state("running")
        start_ts = time.time()
        hgs = int(cfg.get("limits", {}).get("host_group_size", 32))
        chunks = [job.targets[i:i + hgs] for i in range(0, len(job.targets), hgs)]

        high_risk_ports = set(int(p) for p in cfg.get("alerts", {}).get("high_risk_ports", []))
        high_risk_lines = []
        open_count = 0
        all_results = []

        for idx, chunk in enumerate(chunks, 1):
            out_file = job.dir / f"chunk_{idx:02d}.greppable"
            rc, out = run_nmap_chunk(chunk, profile, out_file)
            (job.dir / f"chunk_{idx:02d}.stdout.log").write_text(out or "", encoding="utf-8")

            try:
                content = out_file.read_text(encoding="utf-8") if out_file.exists() else ""
            except Exception:
                content = ""

            for line in content.splitlines():
                if not line.startswith("Host:"):
                    continue
                ip_match = re.search(r"Host:\s+([0-9.]+)", line)
                if not ip_match:
                    continue
                ip = ip_match.group(1)
                ports = parse_greppable_line(line)
                if ports:
                    open_ports = sorted({p['port'] for p in ports})
                    open_count += len(open_ports)
                    all_results.append({"ip": ip, "ports": open_ports})
                    risk_hits = [p for p in open_ports if p in high_risk_ports]
                    if risk_hits:
                        high_risk_lines.append(f"{ip} -> {','.join(map(str, risk_hits))}")
            job.tick(inc=len(chunk))

# ...existing code...
        # 只保留「有開放埠」的主機，並依 IP 排序
        filtered_results = [item for item in all_results if item.get("ports")]
        filtered_results.sort(key=lambda x: tuple(int(part) for part in x["ip"].split(".")))

        (job.dir / "results.json").write_text(
            json.dumps(filtered_results, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )
# ...existing code...

        dur = int(time.time() - start_ts)
        job.summary.update({"open_ports": open_count, "duration_sec": dur})
        job.set_state("succeeded")

        throttle = int(cfg.get("alerts", {}).get("throttle_seconds", 300))
        send_telegram_alert(high_risk_lines, throttle)

    # ---------- API 查詢 ----------
    def get_status(self, job_id: str):
        p = SCAN_DIR / job_id / "status.json"
        if p.exists():
            return json.loads(p.read_text(encoding="utf-8"))
        return None

    def get_results(self, job_id: str, mode: str = "summary"):
        p = SCAN_DIR / job_id / "results.json"
        if p.exists():
            data = json.loads(p.read_text(encoding="utf-8"))
            if mode == "summary":
                return data
            return {"items": data}
        return None

# 單例
manager = ScanManager()
