#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ===============================================================
# Guardian One Web App - v4.7.1
# Author: Dylan
# Last Modified: 2025-08-09
# ---------------------------------------------------------------
# Changes in v4.7.1
# - Bumped version header and changelog only; no functional changes
# - Keeps dual-mode nmap scan API and safety checks from v4.7.0
#
# Changes in v4.7.0
# - Added dual-mode nmap scan API (/api/scan): yaml_list | cidr
# - Supports deny list merging and RFC1918-only restriction
# - Requires ack_risk=true for CIDR scans (safety)
# - New endpoints: /api/monitored-ips, /scan page route
# - All logs/messages are ASCII to avoid Unicode decode issues
# - Kept Git push flow via monitor.run_git_push()
# ===============================================================

import sys
import os
import asyncio
import logging
from pathlib import Path
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from apscheduler.schedulers.background import BackgroundScheduler
import yaml
import subprocess

# -------- Load monitoring core (monitor.py) --------
try:
    from monitor import (
        HealthMonitor, setup_logging, check_prerequisites,
        YAML_CONFIG_FILE, get_category_icon, SCRIPT_VERSION as MONITOR_VERSION,
        ICON_LOCATION_OK, ICON_LOCATION_FAIL, ICON_CATEGORY_MONITORING,
        ICON_ARROW_RIGHT, ICON_ARROW_DOWN, BASE_DIR,
        GIT_REPO_HTML_PATH
    )
except Exception as e:
    print("ERROR: cannot import monitor module. Please ensure monitor.py exists and is valid.")
    print(f"Detail: {e}")
    sys.exit(1)

# -------- Load scan worker (dual-mode) --------
try:
    # manager exposes: start_scan(profile_name, mode, cidr, deny_ips_override, ack_risk), get_status(), get_results()
    from scan_worker import manager
except Exception as e:
    manager = None
    logging.warning(f"scan_worker not available: {e}. Scan API will be disabled.")

# -------- App init --------
setup_logging()
check_prerequisites()

app = Flask(__name__, static_url_path="/static")
app.secret_key = os.urandom(24)

TEMPLATE_YAML_CONFIG_FILE = BASE_DIR / "template_ap_list.yaml"

# -------- In-memory last report result (for index page) --------
latest_results = {
    "report_data": {
        "script_version": MONITOR_VERSION,
        "update_time": "Waiting for first monitoring run...",
        "total_devices": 0, "ok_devices": 0, "fail_devices": 0,
        "sorted_locations": [],
        "icons": {
            "location_ok": ICON_LOCATION_OK,
            "location_fail": ICON_LOCATION_FAIL,
            "monitoring": ICON_CATEGORY_MONITORING,
            "arrow_right": ICON_ARROW_RIGHT,
            "arrow_down": ICON_ARROW_DOWN
        }
    },
    "system_resources": {
        "cpu": {"usage": 0, "status_text": "N/A", "class": "ok", "warn": 70, "error": 90},
        "mem": {"usage": 0, "status_text": "N/A", "class": "ok", "warn": 70, "error": 90},
        "disk": {"usage": 0, "status_text": "N/A", "class": "ok", "warn": 80, "error": 90},
        "load_avg": 0
    }
}

# -------- Git helper (only run as root) --------
def push_if_git_changed(monitor: HealthMonitor):
    if os.geteuid() != 0:
        logging.info("Not running as root, skip Git status check and push.")
        return
    try:
        result = subprocess.run(['git', 'diff', '--quiet'], cwd=GIT_REPO_HTML_PATH.parent)
        if result.returncode != 0:
            logging.info("Git status changed. Running auto push...")
            monitor.run_git_push()
        else:
            logging.info("Git status clean. Skip push.")
    except Exception as e:
        logging.error(f"Git status check failed: {e}")

# -------- Background monitoring job (existing health checks) --------
def run_monitoring_job():
    logging.info("Background monitoring job started.")
    try:
        monitor = HealthMonitor()
        system_resources = monitor.get_system_resources()

        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(monitor.process_all_checks())
        loop.close()

        report_data = monitor.prepare_report_data()

        monitor.send_telegram_notification()
        monitor.render_and_save_report(report_data, system_resources)
        push_if_git_changed(monitor)

        global latest_results
        latest_results = {
            "report_data": report_data,
            "system_resources": system_resources
        }

        logging.info("Background monitoring job finished.")
    except Exception as e:
        logging.error(f"Background job error: {e}", exc_info=True)

# =========================
# Routes
# =========================

@app.route('/')
def report():
    return render_template(
        'report.html',
        report=latest_results["report_data"],
        system_resources=latest_results["system_resources"],
        get_category_icon=get_category_icon
    )

@app.route('/config', methods=['GET', 'POST'])
def config():
    if request.method == 'POST':
        content = request.form['content']
        try:
            yaml.safe_load(content)  # validate
            with open(YAML_CONFIG_FILE, 'w', encoding='utf-8') as f:
                f.write(content)
            flash('Config saved. Update triggered.', 'success')
            if 'scheduler' in globals():
                # trigger immediate run
                scheduler.get_job('monitoring_job').modify(next_run_time=datetime.now())
        except yaml.YAMLError as e:
            flash(f'YAML format error: {e}', 'error')
        except IOError as e:
            flash(f'Write failed: {e}', 'error')
        return redirect(url_for('config'))

    try:
        raw_content = YAML_CONFIG_FILE.read_text(encoding='utf-8')
        initial_data = yaml.safe_load(raw_content)
    except Exception as e:
        raw_content = f"# Failed to read config: {e}"
        initial_data = {}
        flash(f'Read failed: {e}', 'error')

    template_data = {}
    try:
        if TEMPLATE_YAML_CONFIG_FILE.exists():
            template_data = yaml.safe_load(TEMPLATE_YAML_CONFIG_FILE.read_text(encoding='utf-8'))
        else:
            flash('Warning: template_ap_list.yaml not found.', 'warning')
    except Exception as e:
        flash(f'Template read failed: {e}', 'error')

    return render_template('config.html',
                           content=raw_content,
                           initial_data=initial_data,
                           template_data=template_data)

# -------- Scan page (simple UI; template provided separately) --------
@app.route('/scan')
def scan_page():
    return render_template('scan.html')

# -------- Provide monitored IPs (for blacklist checkbox) --------
@app.route('/api/monitored-ips')
def api_monitored_ips():
    try:
        with open(YAML_CONFIG_FILE, 'r', encoding='utf-8') as f:
            cfg = yaml.safe_load(f) or {}
        locs = cfg.get('locations', {})
        ips, seen = [], set()
        for _, cats in locs.items():
            if not isinstance(cats, dict):
                continue
            for _, devs in cats.items():
                if not isinstance(devs, list):
                    continue
                for d in devs:
                    ip = str(d.get('ip', '')).strip()
                    if ip and ip not in seen:
                        seen.add(ip)
                        ips.append(ip)
        return jsonify({"items": sorted(ips)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# -------- Dual-mode scan API --------
# Body fields:
#   profile: "light" | "standard" (optional; default from env/config)
#   mode: "yaml_list" | "cidr" (optional; falls back to config targets.mode)
#   cidr: "10.10.101.0/24" (required for cidr mode; RFC1918 only)
#   deny_ips: [ "10.10.101.1", ... ] (optional; will merge with config deny)
#   ack_risk: true (required for cidr mode if safety.require_ack_for_cidr = true)
@app.route('/api/scan', methods=['POST'])
def api_scan_create():
    if manager is None:
        return jsonify({"error": "scan service unavailable"}), 503
    try:
        body = request.get_json(silent=True) or {}
        profile = body.get('profile')
        mode = (body.get('mode') or '').strip()
        cidr = (body.get('cidr') or '').strip()
        deny = body.get('deny_ips') or []
        ack_risk = bool(body.get('ack_risk', False))

        job_id = manager.start_scan(
            profile_name=profile,
            mode=mode or None,
            cidr=cidr or None,
            deny_ips_override=deny,
            ack_risk=ack_risk
        )
        return jsonify({"job_id": job_id, "state": "queued"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/api/scan/<job_id>/status')
def api_scan_status(job_id):
    if manager is None:
        return jsonify({"error": "scan service unavailable"}), 503
    st = manager.get_status(job_id)
    if not st:
        return jsonify({"error": "job not found"}), 404
    return jsonify(st)

@app.route('/api/scan/<job_id>/results')
def api_scan_results(job_id):
    if manager is None:
        return jsonify({"error": "scan service unavailable"}), 503
    mode = request.args.get('format', 'summary')
    rs = manager.get_results(job_id, mode)
    if not rs:
        return jsonify({"error": "job not found"}), 404
    return jsonify(rs)

# =========================
# Main
# =========================
if __name__ == '__main__':
    scheduler = BackgroundScheduler(daemon=True)
    scheduler.add_job(run_monitoring_job, 'interval', minutes=5, id='monitoring_job')
    scheduler.start()

    logging.info("Starting Flask web server and first monitoring run...")
    run_monitoring_job()
    # Note: Flask built-in server is for dev. Keep as-is for your device.
    app.run(host='0.0.0.0', port=5000, debug=False)
