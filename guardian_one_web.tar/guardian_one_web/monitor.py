#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ===============================================================
# Network Device Health Monitoring Module - v4.7.1
# Author: Dylan 
# Last Modified: 2025-08-09
# ---------------------------------------------------------------
# Changelog
# v4.7.1
#   - Align with app v4.7.1. No logic change to health checks.
#   - start_scan() proxy now accepts dual-mode params:
#     (profile_name, mode, cidr, deny_ips_override, ack_risk)
#   - Added richer docstrings and inline comments.
#   - Kept UTF-8 throughout; logs avoid special emojis to reduce console issues.
#
# v4.7.0
#   - Prep for dual-mode scan integration (yaml_list | cidr).
#   - Hardened helper get_monitored_ips() for blacklist merging.
#
# v4.6.1
#   - Fixed encoding issues; unified file to UTF-8.
#   - Added start_scan() proxy (initial version) and get_monitored_ips().
#   - Kept report rendering, Telegram alerts, Git push.
#
# v4.3.2
#   - Added explicit logging for failed device checks.
#
# v4.3.1
#   - Added a dummy url_for function for standalone execution.
#
# v4.3.0
#   - Refactored for Flask integration.
# ===============================================================

import os
import sys
import asyncio
import subprocess
import logging
import re
import json
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple

try:
    from dotenv import load_dotenv
    import yaml
    import requests
    import aiohttp
    import psutil
    from jinja2 import Environment, BaseLoader
    from icmplib import async_ping
except ImportError as e:
    print(f"Missing required Python packages: {e}")
    print("Activate venv first (source venv/bin/activate), then:")
    print("  pip install -r requirements.txt")
    sys.exit(1)

# ------------------------------
# Constants & paths
# ------------------------------
SCRIPT_VERSION = "4.7.1"
BASE_DIR = Path(__file__).resolve().parent

load_dotenv(BASE_DIR / ".env")
YAML_CONFIG_FILE = BASE_DIR / "ap_list.yaml"
LOG_FILE = Path(os.getenv("LOG_FILE", "/var/log/device_health.log"))
UNREACHABLE_COUNT_FILE = Path(os.getenv("UNREACHABLE_COUNT_FILE", "/tmp/ap_unreachable_count.json"))
HTML_REPORT_PATH = Path(os.getenv("HTML_REPORT_PATH", "/var/www/html/index.html"))
GIT_REPO_HTML_PATH = Path(os.getenv("GIT_REPO_HTML_PATH", "${HOME}/guardian_one_web_Report_Pages/index.html"))
GIT_PUSH_SCRIPT_PATH = BASE_DIR / "auto_git_push_report.sh"

HTTP_RETRIES = int(os.getenv("HTTP_RETRIES", 3))
PING_RETRIES = int(os.getenv("PING_RETRIES", 3))
UNREACHABLE_THRESHOLD = int(os.getenv("UNREACHABLE_THRESHOLD", 3))
PING_TIMEOUT = float(os.getenv("PING_TIMEOUT", 1.0))
REQUEST_TIMEOUT = float(os.getenv("CURL_TIMEOUT", 4.0))
SUCCESS_HTTP_CODES = {200, 400, 401, 403, 405}

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

# Simple inline SVG icons for template rendering
ICON_LOCATION_OK = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="ok"><path d="M12 22s-8-4-8-10a8 8 0 0 1 16 0c0 6-8 10-8 10z"/><circle cx="12" cy="10" r="3"/></svg>'
ICON_LOCATION_FAIL = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="fail"><path d="M12 22s-8-4-8-10a8 8 0 0 1 16 0c0 6-8 10-8 10z"/><circle cx="12" cy="10" r="3"/><line x1="12" y1="12" x2="12" y2="12.01"/><line x1="12" y1="16" x2="12" y2="16.01"/></svg>'
ICON_CATEGORY_AP = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.55A9 9 0 0 1 12 8a9 9 0 0 1 7 4.55"/><path d="M2 8.8C8.04 2.93 16.73 2.59 22 8.8"/><line x1="12" x2="12" y1="20" y2="20.01"/></svg>'
ICON_CATEGORY_FIREWALL_ROUTER = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>'
ICON_CATEGORY_SWITCH = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="8" x="2" y="2" rx="2" ry="2"/><rect width="20" height="8" x="2" y="14" rx="2" ry="2"/><line x1="6" x2="6" y1="6" y2="6"/><line x1="6" x2="6" y1="18" y2="18"/></svg>'
ICON_CATEGORY_PRINTERS = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>'
ICON_CATEGORY_DEFAULT = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>'
ICON_CATEGORY_MONITORING = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 7V4"/><path d="M12 18v3"/><path d="M15 9l2.7 2.7"/><path d="M6.3 17.7L9 15"/><path d="M3 12h3"/><path d="M18 12h3"/><path d="M17.7 6.3L15 9"/><path d="M9 15l-2.7 2.7"/></svg>'
ICON_ARROW_RIGHT = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>'
ICON_ARROW_DOWN = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>'

# ------------------------------
# Setup & sanity checks
# ------------------------------
def setup_logging():
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(levelname)s] %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S',
        handlers=[
            logging.FileHandler(LOG_FILE, mode='a', encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )

def check_prerequisites():
    if not YAML_CONFIG_FILE.is_file():
        logging.critical(f"YAML config not found: {YAML_CONFIG_FILE}")
        sys.exit(1)
    logging.info("Prerequisites OK.")

def get_category_icon(category_type: str) -> str:
    return {
        "AP": ICON_CATEGORY_AP,
        "Firewall": ICON_CATEGORY_FIREWALL_ROUTER,
        "Switch": ICON_CATEGORY_SWITCH,
        "Printers": ICON_CATEGORY_PRINTERS,
    }.get(category_type, ICON_CATEGORY_DEFAULT)

# ===============================================================
# Core class
# ===============================================================
class HealthMonitor:
    """
    - Runs ICMP + basic HTTP(S) reachability checks against devices defined in ap_list.yaml
    - Produces HTML report (templates/report.html)
    - Sends Telegram alerts for repeated unreachable devices
    - Optionally triggers Git push script
    - Provides helper methods to integrate Phase-1/2 scanning flows
    """
    def __init__(self):
        self.unreachable_counts = self._load_unreachable_counts()
        self.device_results: List[Dict[str, Any]] = []
        self.unreachable_devices_by_category: Dict[str, List[str]] = {}
        self.total_unreachable = 0
        self.cpu_warn = int(os.getenv("CPU_WARN", 70))
        self.cpu_error = int(os.getenv("CPU_ERROR", 90))
        self.mem_warn = int(os.getenv("MEM_WARN", 70))
        self.mem_error = int(os.getenv("MEM_ERROR", 90))
        self.disk_warn = int(os.getenv("DISK_WARN", 80))
        self.disk_error = int(os.getenv("DISK_ERROR", 90))

    # ---------- Scan integration: list monitored IPs, start scans (dual-mode proxy) ----------
    def get_monitored_ips(self) -> List[str]:
        """
        Return a de-duplicated list of IPs from ap_list.yaml (monitored inventory).
        Useful for building a suggested deny list before network-wide scans.
        """
        if not YAML_CONFIG_FILE.exists():
            return []
        try:
            cfg = yaml.safe_load(YAML_CONFIG_FILE.read_text(encoding='utf-8')) or {}
        except Exception:
            return []
        ips, seen = [], set()
        for _, cats in (cfg.get("locations") or {}).items():
            if not isinstance(cats, dict):
                continue
            for _, devices in cats.items():
                if not isinstance(devices, list):
                    continue
                for d in devices:
                    ip = str(d.get("ip", "")).strip()
                    if ip and ip not in seen:
                        seen.add(ip)
                        ips.append(ip)
        return ips

    def start_scan(
        self,
        profile_name: Optional[str] = None,
        mode: Optional[str] = None,                # "yaml_list" | "cidr" | None (let scan_worker decide)
        cidr: Optional[str] = None,                # e.g., "10.10.101.0/24" if mode == "cidr"
        deny_ips_override: Optional[List[str]] = None,
        ack_risk: bool = False
    ) -> str:
        """
        Proxy to scan_worker.manager.start_scan() with dual-mode params.
        This keeps monitor.py as the single integration point for the web app.
        - profile_name: scan profile ("light" | "standard" | None to use default)
        - mode: "yaml_list" scans only ap_list.yaml IPs; "cidr" scans a provided RFC1918 network
        - cidr: CIDR block when mode="cidr"
        - deny_ips_override: extra deny list to merge (UI-selected or manual inputs)
        - ack_risk: must be True when safety requires a risk acknowledgement for CIDR scans
        Returns job_id.
        """
        try:
            # Late import to avoid circular deps at app boot
            from scan_worker import manager
        except Exception as e:
            raise RuntimeError(f"scan_worker import failed: {e}")

        return manager.start_scan(
            profile_name=profile_name or None,
            mode=mode or None,
            cidr=cidr or None,
            deny_ips_override=list(deny_ips_override or []),
            ack_risk=bool(ack_risk),
        )

    # ---------- Existing health-check logic ----------
    def _load_unreachable_counts(self) -> Dict[str, int]:
        if not UNREACHABLE_COUNT_FILE.exists():
            return {}
        try:
            with open(UNREACHABLE_COUNT_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return {}

    def _save_unreachable_counts(self):
        try:
            with open(UNREACHABLE_COUNT_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.unreachable_counts, f, ensure_ascii=False, indent=2)
        except IOError as e:
            logging.error(f"Failed to write unreachable-count state: {e}")

    async def _check_web_service(self, session: aiohttp.ClientSession, ip: str, port: Optional[int]) -> Tuple[str, Optional[int]]:
        # Try the most likely protocol/port first, then fallback
        protocols_ports = []
        if port:
            if port == 443:
                protocols_ports.append(('https', port))
            elif port == 80:
                protocols_ports.append(('http', port))
            else:
                protocols_ports.extend([('https', port), ('http', port)])
        else:
            protocols_ports.extend([('https', 443), ('http', 80)])

        for proto, p in protocols_ports:
            url = f"{proto}://{ip}:{p}"
            try:
                async with session.get(url, ssl=False, timeout=REQUEST_TIMEOUT) as response:
                    if response.status in SUCCESS_HTTP_CODES:
                        return f"{proto.upper()}:{response.status}", response.status
            except (asyncio.TimeoutError, aiohttp.ClientError):
                continue
        return "Web Failed", None

    async def check_device_connectivity(self, session: aiohttp.ClientSession, device: Dict[str, Any]) -> Dict[str, Any]:
        ip = device['ip']
        result = device.copy()
        try:
            host = await async_ping(ip, count=PING_RETRIES, timeout=PING_TIMEOUT, privileged=False)
            if not host.is_alive:
                result.update({'status': 'FAIL', 'detail': f'Ping Failed ({PING_RETRIES} retries)'})
                return result
        except Exception as e:
            result.update({'status': 'FAIL', 'detail': f'Ping Error: {e}'})
            return result

        web_detail, http_code = await self._check_web_service(session, ip, device.get('port'))
        if http_code in SUCCESS_HTTP_CODES:
            result.update({'status': 'OK', 'detail': web_detail})
        else:
            result.update({'status': 'FAIL', 'detail': f"Web Failed (Ping OK, Last: {web_detail})"})
        return result

    def get_system_resources(self) -> Dict[str, Any]:
        logging.info("Collecting system resource usage...")
        cpu_usage = psutil.cpu_percent(interval=1)
        mem = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        load_avg = psutil.getloadavg()[1]

        def get_status(value, warn, error):
            if value >= error:
                return "ERROR", "fail"
            if value >= warn:
                return "WARN", "warn"
            return "OK", "ok"

        cpu_status_text, cpu_class = get_status(cpu_usage, self.cpu_warn, self.cpu_error)
        mem_status_text, mem_class = get_status(mem.percent, self.mem_warn, self.mem_error)
        disk_status_text, disk_class = get_status(disk.percent, self.disk_warn, self.disk_error)

        return {
            "cpu": {"usage": cpu_usage, "status_text": cpu_status_text, "class": cpu_class, "warn": self.cpu_warn, "error": self.cpu_error},
            "mem": {"usage": mem.percent, "status_text": mem_status_text, "class": mem_class, "warn": self.mem_warn, "error": self.mem_error},
            "disk": {"usage": disk.percent, "status_text": disk_status_text, "class": disk_class, "warn": self.disk_warn, "error": self.disk_error},
            "load_avg": load_avg
        }

    async def process_all_checks(self):
        logging.info("Starting device health checks...")
        try:
            with open(YAML_CONFIG_FILE, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f) or {}
        except Exception as e:
            logging.critical(f"Failed to read YAML config: {e}")
            return

        all_devices_for_report, tasks, processed_ips = [], [], set()
        async with aiohttp.ClientSession() as session:
            for location, types in (config.get('locations') or {}).items():
                for type_name, devices in (types or {}).items():
                    if not isinstance(devices, list):
                        continue
                    for device in devices:
                        if not all(k in device for k in ['ip', 'name']):
                            continue
                        if device['ip'] in processed_ips:
                            logging.warning(f"Skip duplicate IP: {device['ip']}")
                            continue
                        processed_ips.add(device['ip'])
                        device_info = {**device, 'location': location, 'type': type_name}
                        all_devices_for_report.append(device_info)
                        tasks.append(self.check_device_connectivity(session, device_info))

            check_results = await asyncio.gather(*tasks, return_exceptions=True)

        result_map = {res['ip']: res for res in check_results if isinstance(res, dict) and 'ip' in res}
        for device in all_devices_for_report:
            ip = device['ip']
            result = result_map.get(ip, {'status': 'FAIL', 'detail': 'Check task exception'})
            device.update(result)

            if device['status'] != 'OK':
                logging.warning(f"Device check failed: {device['name']} ({device['ip']}) - {device['detail']}")

            if device['status'] == 'OK':
                if ip in self.unreachable_counts:
                    del self.unreachable_counts[ip]
            else:
                count = self.unreachable_counts.get(ip, 0) + 1
                self.unreachable_counts[ip] = count
                if count >= UNREACHABLE_THRESHOLD:
                    self.total_unreachable += 1
                    key = f"{device['location']}:{device['type']}"
                    self.unreachable_devices_by_category.setdefault(key, []).append(
                        f"* {device['name']} ({ip}) - {device['detail']}"
                    )

        self.device_results = all_devices_for_report
        self._save_unreachable_counts()

    def prepare_report_data(self) -> Dict[str, Any]:
        """Aggregate results for Jinja template rendering."""
        report_data = {
            'script_version': SCRIPT_VERSION,
            'update_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'total_devices': 0, 'ok_devices': 0, 'fail_devices': 0,
            'locations_data': {},
            'icons': {
                'location_ok': ICON_LOCATION_OK, 'location_fail': ICON_LOCATION_FAIL,
                'monitoring': ICON_CATEGORY_MONITORING, 'arrow_right': ICON_ARROW_RIGHT,
                'arrow_down': ICON_ARROW_DOWN
            }
        }
        for result in self.device_results:
            loc, cat = result['location'], result['type']
            if loc not in report_data['locations_data']:
                report_data['locations_data'][loc] = {'categories': {}, 'status': 'ok'}
            if cat not in report_data['locations_data'][loc]['categories']:
                report_data['locations_data'][loc]['categories'][cat] = {'devices': [], 'ok': 0, 'fail': 0}

            report_data['locations_data'][loc]['categories'][cat]['devices'].append(result)
            report_data['total_devices'] += 1
            if result.get('status') == 'OK':
                report_data['ok_devices'] += 1
                report_data['locations_data'][loc]['categories'][cat]['ok'] += 1
            else:
                report_data['fail_devices'] += 1
                report_data['locations_data'][loc]['categories'][cat]['fail'] += 1
                report_data['locations_data'][loc]['status'] = 'fail'

        def sort_key(item):
            name = item[0]
            if re.match(r'^[0-9]', name): return (1, name)
            if re.match(r'^[A-Za-z]', name): return (2, name)
            return (0, name)

        sorted_locations = sorted(report_data['locations_data'].items(), key=sort_key)
        has_fail = [item for item in sorted_locations if item[1]['status'] == 'fail']
        ok_locs = [item for item in sorted_locations if item[1]['status'] == 'ok']
        report_data['sorted_locations'] = has_fail + ok_locs
        return report_data

    def render_and_save_report(self, report_data: Dict[str, Any], system_resources: Dict[str, Any]):
        """Render HTML report from templates/report.html and write to disk."""
        logging.info("Rendering HTML report...")
        try:
            template_path = BASE_DIR / 'templates' / 'report.html'
            if not template_path.exists():
                logging.error(f"Template not found: {template_path}")
                return

            template_str = template_path.read_text(encoding='utf-8')
            env = Environment(loader=BaseLoader())
            template = env.from_string(template_str)

            # Standalone dummy url_for when not in Flask context
            def dummy_url_for(endpoint, **values):
                return "#"

            html_content = template.render(
                report=report_data,
                system_resources=system_resources,
                get_category_icon=get_category_icon,
                url_for=dummy_url_for
            )
            HTML_REPORT_PATH.write_text(html_content, encoding='utf-8')
            if GIT_REPO_HTML_PATH.parent.exists():
                subprocess.run(['cp', str(HTML_REPORT_PATH), str(GIT_REPO_HTML_PATH)], check=True)
            logging.info("HTML report generated.")
        except Exception as e:
            logging.error(f"Failed to render/write HTML report: {e}", exc_info=True)

    def get_embedded_template(self) -> str:
        # Fallback minimal HTML when template file is missing
        return "<h1>Monitoring Report</h1><p>Template file not found.</p>"

    def send_telegram_notification(self):
        if not self.total_unreachable > 0 or not TELEGRAM_TOKEN or not TELEGRAM_CHAT_ID:
            return
        logging.info("Sending Telegram alert...")
        parts = [
            "<b>Device Health Alert</b>",
            f"<b>Time:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "<b>Repeated unreachable list:</b>\n"
        ]
        for key in sorted(self.unreachable_devices_by_category.keys()):
            location, type_name = key.split(':')
            devices_str = "\n".join(self.unreachable_devices_by_category[key])
            parts.append(f"<b>Location:</b> {location}\n<b>Category:</b> {type_name}\n{devices_str}\n")
        try:
            requests.post(
                f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage",
                data={'chat_id': TELEGRAM_CHAT_ID, 'text': "\n".join(parts), 'parse_mode': 'HTML'},
                timeout=30
            ).raise_for_status()
            logging.info("Telegram alert sent.")
        except requests.exceptions.RequestException as e:
            logging.error(f"Telegram alert failed: {e}")

    def run_git_push(self):
        if not GIT_PUSH_SCRIPT_PATH.is_file():
            return
        logging.info("Executing Git auto push script...")
        try:
            subprocess.run(['sudo', '-u', 'dylan', str(GIT_PUSH_SCRIPT_PATH)], capture_output=True, text=True, check=True)
            logging.info("Git auto push completed.")
        except subprocess.CalledProcessError as e:
            logging.error(f"Git auto push failed (code {e.returncode}): {e.stderr}")

# ===============================================================
# CLI entrypoint for standalone runs
# ===============================================================
async def main_runner():
    """Convenience CLI: run health checks, render report, alert, optional git push."""
    setup_logging()
    start_time = datetime.now()
    logging.info(f"===== Device Health Check start (v{SCRIPT_VERSION}) =====")
    check_prerequisites()
    monitor = HealthMonitor()
    system_resources = monitor.get_system_resources()
    await monitor.process_all_checks()
    report_data = monitor.prepare_report_data()
    monitor.render_and_save_report(report_data, system_resources)
    monitor.send_telegram_notification()
    if os.geteuid() == 0:
        monitor.run_git_push()
    elapsed = (datetime.now() - start_time).total_seconds()
    logging.info(f"Total elapsed: {elapsed:.2f} sec")
    logging.info("===== Device Health Check finished =====\n")

if __name__ == "__main__":
    asyncio.run(main_runner())
