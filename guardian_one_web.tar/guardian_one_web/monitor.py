#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ===============================================================
# Network Device Health Monitoring Module - v5.0
# Author: Dylan (Refactored & Debugged by Gemini)
# Last Modified: 2026-03-10
# --- Changelog ---
# v4.5.0: Added dynamic notification settings and per-device monitoring controls.
# v4.3.2: Added explicit logging for failed device checks.
# v4.3.1: Added a dummy url_for function for standalone execution.
# v4.3.0: Refactored for Flask integration.
# ===============================================================

import os
import sys
import asyncio
import subprocess
import logging
import re
import json
import smtplib
import time
from datetime import datetime
from email.message import EmailMessage
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple

try:
    from dotenv import load_dotenv
    import yaml
    import requests
    import aiohttp
    import psutil
    from jinja2 import Environment, BaseLoader
    from icmplib import async_ping
except ImportError as e:
    print(f"錯誤：找不到必要的 Python 套件 ({e})。")
    print("請先啟用虛擬環境 (source venv/bin/activate)，然後執行：")
    print("pip install -r requirements.txt")
    sys.exit(1)

# --- 全局設定與常數 ---
# --- 修正後的全局設定與常數 ---
SCRIPT_VERSION = "5.0"
BASE_DIR = Path(__file__).resolve().parent

# 載入環境變數
load_dotenv(BASE_DIR / ".env")

# 1. 配置文件路徑 (統一收納在專案目錄)
YAML_CONFIG_FILE = BASE_DIR / "ap_list.yaml"
NOTIFICATION_CONFIG_FILE = Path(os.getenv("NOTIFICATION_CONFIG_FILE", str(BASE_DIR / "notification_settings.yaml")))

# 修正：不要使用 Path.home()，改用 BASE_DIR 的隱藏目錄或相對路徑
NOTIFICATION_FALLBACK_CONFIG_FILE = Path(
    os.getenv("NOTIFICATION_FALLBACK_CONFIG_FILE", str(BASE_DIR / ".config" / "notification_settings.yaml"))
)

# 2. 日誌與暫存檔 (修正：改為 guardian 使用者有權限寫入的路徑)
# 建議將日誌放在專案目錄下的 logs 夾，或是直接放在專案根目錄
LOG_FILE = Path(os.getenv("LOG_FILE", str(BASE_DIR / "device_health.log")))
UNREACHABLE_COUNT_FILE = Path(os.getenv("UNREACHABLE_COUNT_FILE", str(BASE_DIR / "ap_unreachable_count.json")))
LAST_RESULTS_FILE = Path(os.getenv("LAST_RESULTS_FILE", str(BASE_DIR / "ap_last_results.json")))
NOTIFICATION_STATE_FILE = Path(os.getenv("NOTIFICATION_STATE_FILE", str(BASE_DIR / "ap_notification_state.json")))

# 3. 報告路徑
# 修正：/var/www/html 可能需要 root 權限，若非必要，建議先存在專案目錄內再透過 Nginx Alias 指向
HTML_REPORT_PATH = Path(os.getenv("HTML_REPORT_PATH", str(BASE_DIR / "report.html")))
GIT_REPO_HTML_PATH = Path(os.getenv("GIT_REPO_HTML_PATH", "/opt/guardian_one_web_Report_Pages/index.html"))
GIT_PUSH_SCRIPT_PATH = BASE_DIR / "auto_git_push_report.sh"

HTTP_RETRIES = int(os.getenv("HTTP_RETRIES", 3))
PING_RETRIES = int(os.getenv("PING_RETRIES", 3))
UNREACHABLE_THRESHOLD = int(os.getenv("UNREACHABLE_THRESHOLD", 3))
PING_TIMEOUT = float(os.getenv("PING_TIMEOUT", 1.0))
PING_PRIVILEGED = os.getenv("PING_PRIVILEGED", "false").strip().lower() in {"1", "true", "yes", "on"}
REQUEST_TIMEOUT = float(os.getenv("CURL_TIMEOUT", 4.0))
SUCCESS_HTTP_CODES = {200, 400, 401, 403, 405}

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

DEFAULT_DEVICE_SETTINGS = {
    "interval_seconds": 300,
    "retry_count": PING_RETRIES,
    "retry_interval_seconds": 1,
    "request_timeout": REQUEST_TIMEOUT,
    "renotify_fail_count": 0,
    "renotify_enabled": False,
    "notification_channels": ["telegram"]
}

ICON_LOCATION_OK = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="ok"><path d="M12 22s-8-4-8-10a8 8 0 0 1 16 0c0 6-8 10-8 10z"/><circle cx="12" cy="10" r="3"/></svg>'
ICON_LOCATION_FAIL = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="fail"><path d="M12 22s-8-4-8-10a8 8 0 0 1 16 0c0 6-8 10-8 10z"/><circle cx="12" cy="10" r="3"/><line x1="12" y1="12" x2="12" y2="12.01"/><line x1="12" y1="16" x2="12" y2="16.01"/></svg>'
ICON_CATEGORY_AP = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.55A9 9 0 0 1 12 8a9 9 0 0 1 7 4.55"/><path d="M2 8.8C8.04 2.93 16.73 2.59 22 8.8"/><line x1="12" x2="12" y1="20" y2="20.01"/></svg>'
ICON_CATEGORY_FIREWALL_ROUTER = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>'
ICON_CATEGORY_SWITCH = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="8" x="2" y="2" rx="2" ry="2"/><rect width="20" height="8" x="2" y="14" rx="2" ry="2"/><line x1="6" x2="6" y1="6" y2="6"/><line x1="6" x2="6" y1="18" y2="18"/></svg>'
ICON_CATEGORY_PRINTERS = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>'
ICON_CATEGORY_DEFAULT = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>'
ICON_CATEGORY_MONITORING = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 7V4"/><path d="M12 18v3"/><path d="M15 9l2.7 2.7"/><path d="M6.3 17.7L9 15"/><path d="M3 12h3"/><path d="M18 12h3"/><path d="M17.7 6.3L15 9"/><path d="M9 15l-2.7 2.7"/></svg>'
ICON_ARROW_RIGHT = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>'
ICON_ARROW_DOWN = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>'

def setup_logging():
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(levelname)s] %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S',
        handlers=[
            logging.FileHandler(LOG_FILE, mode='a', encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )

def check_prerequisites():
    if not YAML_CONFIG_FILE.is_file():
        logging.critical(f"找不到 YAML 設定檔：{YAML_CONFIG_FILE}。腳本終止。")
        sys.exit(1)
    logging.info("環境檢查完成。")

def load_notification_settings() -> Dict[str, Any]:
    default_config = {
        "enabled": True,
        "cooldown_minutes": 30,
        "send_recovery": False,
        "channels": {
            "telegram": {
                "enabled": bool(TELEGRAM_TOKEN and TELEGRAM_CHAT_ID),
                "token": TELEGRAM_TOKEN or "",
                "chat_ids": [TELEGRAM_CHAT_ID] if TELEGRAM_CHAT_ID else []
            },
            "email": {
                "enabled": False,
                "smtp_host": "",
                "smtp_port": 587,
                "use_tls": True,
                "username": "",
                "password": "",
                "from": "",
                "to": [],
                "subject_prefix": "[GuardianOne]"
            }
        }
    }
    preferred = resolve_notification_config_path()
    existing_files = [p for p in [preferred, NOTIFICATION_CONFIG_FILE, NOTIFICATION_FALLBACK_CONFIG_FILE] if p.exists()]
    # 去重且保留順序（確保優先讀取可寫入的有效設定路徑）
    unique_files = []
    for path in existing_files:
        if path not in unique_files:
            unique_files.append(path)

    for config_file in unique_files:
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                loaded = yaml.safe_load(f) or {}
            if not isinstance(loaded, dict):
                continue
            merged = default_config.copy()
            merged.update({k: v for k, v in loaded.items() if k != 'channels'})
            channels = default_config['channels'].copy()
            channels.update(loaded.get('channels', {}))
            for key in ['telegram', 'email']:
                merged_channel = default_config['channels'][key].copy()
                merged_channel.update(channels.get(key, {}))
                channels[key] = merged_channel
            merged['channels'] = channels
            return merged
        except Exception as e:
            logging.error(f"讀取通知設定失敗 ({config_file})，改用下一個來源: {e}")
    return default_config


def save_notification_settings(settings: Dict[str, Any]) -> Path:
    content = yaml.safe_dump(settings, allow_unicode=True, sort_keys=False)
    config_file = resolve_notification_config_path()
    config_file.parent.mkdir(parents=True, exist_ok=True)
    config_file.write_text(content, encoding='utf-8')
    return config_file


def resolve_notification_config_path() -> Path:
    """回傳可寫入的通知設定路徑，避免每次儲存都遇到權限問題。"""
    primary_parent = NOTIFICATION_CONFIG_FILE.parent
    try:
        if NOTIFICATION_CONFIG_FILE.exists() and os.access(NOTIFICATION_CONFIG_FILE, os.W_OK):
            return NOTIFICATION_CONFIG_FILE
        if primary_parent.exists() and os.access(primary_parent, os.W_OK):
            return NOTIFICATION_CONFIG_FILE
    except Exception:
        pass
    return NOTIFICATION_FALLBACK_CONFIG_FILE


def normalize_device_settings(device: Dict[str, Any]) -> Dict[str, Any]:
    settings = DEFAULT_DEVICE_SETTINGS.copy()
    settings.update({k: device.get(k, v) for k, v in DEFAULT_DEVICE_SETTINGS.items()})
    try:
        settings['interval_seconds'] = max(5, int(settings['interval_seconds']))
        settings['retry_count'] = max(1, int(settings['retry_count']))
        settings['retry_interval_seconds'] = max(0, int(settings['retry_interval_seconds']))
        settings['request_timeout'] = max(1.0, float(settings['request_timeout']))
        settings['renotify_fail_count'] = max(1, int(settings['renotify_fail_count'])) if settings['renotify_enabled'] else 0
        channels = settings.get('notification_channels') or ['telegram']
        if isinstance(channels, str):
            channels = [channels]
        settings['notification_channels'] = [c for c in channels if c in {'telegram', 'email'}] or ['telegram']
    except Exception:
        settings = DEFAULT_DEVICE_SETTINGS.copy()
    return settings

def get_category_icon(category_type: str) -> str:
    return {
        "AP": ICON_CATEGORY_AP,
        "Firewall": ICON_CATEGORY_FIREWALL_ROUTER,
        "Switch": ICON_CATEGORY_SWITCH,
    }.get(category_type, ICON_CATEGORY_DEFAULT)

class HealthMonitor:
    def __init__(self):
        self.unreachable_counts = self._load_unreachable_counts()
        self.last_results = self._load_json_file(LAST_RESULTS_FILE)
        self.notification_state = self._load_json_file(NOTIFICATION_STATE_FILE)
        self.notification_settings = load_notification_settings()
        self.device_results: List[Dict[str, Any]] = []
        self.unreachable_devices_by_category: Dict[str, List[str]] = {}
        self.recovered_devices_by_category: Dict[str, List[str]] = {}
        self.channel_notification_messages: Dict[str, List[str]] = {"telegram": [], "email": []}
        self.total_unreachable = 0
        self.cpu_warn = int(os.getenv("CPU_WARN", 70))
        self.cpu_error = int(os.getenv("CPU_ERROR", 90))
        self.mem_warn = int(os.getenv("MEM_WARN", 70))
        self.mem_error = int(os.getenv("MEM_ERROR", 90))
        self.disk_warn = int(os.getenv("DISK_WARN", 80))
        self.disk_error = int(os.getenv("DISK_ERROR", 90))

    def _load_json_file(self, path: Path) -> Dict[str, Any]:
        if not path.exists(): return {}
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return {}

    def _load_unreachable_counts(self) -> Dict[str, int]:
        data = self._load_json_file(UNREACHABLE_COUNT_FILE)
        return {k: int(v) for k, v in data.items()} if isinstance(data, dict) else {}

    def _save_unreachable_counts(self):
        try:
            with open(UNREACHABLE_COUNT_FILE, 'w') as f:
                json.dump(self.unreachable_counts, f)
        except IOError as e:
            logging.error(f"無法寫入異常計數檔案: {e}")

    def _save_runtime_state(self):
        try:
            LAST_RESULTS_FILE.write_text(json.dumps(self.last_results), encoding='utf-8')
            NOTIFICATION_STATE_FILE.write_text(json.dumps(self.notification_state), encoding='utf-8')
        except IOError as e:
            logging.error(f"無法寫入執行狀態檔案: {e}")

    async def _check_web_service(self, session: aiohttp.ClientSession, ip: str, port: Optional[int], request_timeout: float) -> Tuple[str, Optional[int]]:
        protocols_ports = []
        if port:
            if port == 443: protocols_ports.append(('https', port))
            elif port == 80: protocols_ports.append(('http', port))
            else:
                protocols_ports.extend([('https', port), ('http', port)])
        else:
            protocols_ports.extend([('https', 443), ('http', 80)])

        for proto, p in protocols_ports:
            url = f"{proto}://{ip}:{p}"
            try:
                async with session.get(url, ssl=False, timeout=request_timeout) as response:
                    if response.status in SUCCESS_HTTP_CODES:
                        return f"{proto.upper()}:{response.status}", response.status
            except (asyncio.TimeoutError, aiohttp.ClientError):
                continue
        return "Web Failed", None

    async def check_device_connectivity(self, session: aiohttp.ClientSession, device: Dict[str, Any]) -> Dict[str, Any]:
        ip = device['ip']
        result = device.copy()
        retry_count = device.get('retry_count', PING_RETRIES)
        retry_interval = device.get('retry_interval_seconds', 1)
        request_timeout = device.get('request_timeout', REQUEST_TIMEOUT)
        try:
            ping_ok = False
            for attempt in range(retry_count):
                try:
                    host = await async_ping(ip, count=1, timeout=PING_TIMEOUT, privileged=PING_PRIVILEGED)
                except Exception as ping_exc:
                    if PING_PRIVILEGED and "Root privileges are required" in str(ping_exc):
                        logging.warning("ICMP raw socket 權限不足，改用非 privileged 模式重試。")
                        host = await async_ping(ip, count=1, timeout=PING_TIMEOUT, privileged=False)
                    else:
                        raise

                if host.is_alive:
                    ping_ok = True
                    break
                if attempt < retry_count - 1 and retry_interval > 0:
                    await asyncio.sleep(retry_interval)
            if not ping_ok:
                result.update({'status': 'FAIL', 'detail': f'Ping Failed ({retry_count} retries)'})
                return result
        except Exception as e:
            result.update({'status': 'FAIL', 'detail': f'Ping Error: {e}'})
            return result

        web_detail, http_code = await self._check_web_service(session, ip, device.get('port'), request_timeout)
        if http_code in SUCCESS_HTTP_CODES:
            result.update({'status': 'OK', 'detail': web_detail})
        else:
            result.update({'status': 'FAIL', 'detail': f"Web Failed (Ping OK, Last: {web_detail})"})
        return result

    def get_system_resources(self) -> Dict[str, Any]:
        logging.info("檢查本機系統資源使用率...")
        cpu_usage = psutil.cpu_percent(interval=1)
        mem = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        load_avg = psutil.getloadavg()[1]

        def get_status(value, warn, error):
            if value >= error: return "ERROR", "fail"
            if value >= warn: return "WARN", "warn"
            return "OK", "ok"

        cpu_status_text, cpu_class = get_status(cpu_usage, self.cpu_warn, self.cpu_error)
        mem_status_text, mem_class = get_status(mem.percent, self.mem_warn, self.mem_error)
        disk_status_text, disk_class = get_status(disk.percent, self.disk_warn, self.disk_error)

        return {
            "cpu": {"usage": cpu_usage, "status_text": cpu_status_text, "class": cpu_class, "warn": self.cpu_warn, "error": self.cpu_error},
            "mem": {"usage": mem.percent, "status_text": mem_status_text, "class": mem_class, "warn": self.mem_warn, "error": self.mem_error},
            "disk": {"usage": disk.percent, "status_text": disk_status_text, "class": disk_class, "warn": self.disk_warn, "error": self.disk_error},
            "load_avg": load_avg
        }

    async def process_all_checks(self):
        logging.info("開始設備連線檢查...")
        try:
            with open(YAML_CONFIG_FILE, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
        except Exception as e:
            logging.critical(f"讀取 YAML 設定檔失敗: {e}")
            return

        all_devices_for_report, tasks, processed_ips = [], [], set()
        now_ts = int(time.time())
        async with aiohttp.ClientSession() as session:
            for location, types in config.get('locations', {}).items():
                for type_name, devices in types.items():
                    if not isinstance(devices, list): continue
                    for device in devices:
                        if not all(k in device for k in ['ip', 'name']): continue
                        if device['ip'] in processed_ips:
                            logging.warning(f"發現重複 IP [{device['ip']}]，已跳過。")
                            continue
                        processed_ips.add(device['ip'])
                        device_settings = normalize_device_settings(device)
                        device_info = {**device, **device_settings, 'location': location, 'type': type_name}
                        all_devices_for_report.append(device_info)
                        last = self.last_results.get(device_info['ip'], {})
                        elapsed = now_ts - int(last.get('last_check_ts', 0))
                        if elapsed >= device_info['interval_seconds']:
                            tasks.append(self.check_device_connectivity(session, device_info))
                        else:
                            device_info['status'] = last.get('status', 'N/A')
                            device_info['detail'] = last.get('detail', f"等待下次檢查 ({device_info['interval_seconds']} 秒)")

            check_results = await asyncio.gather(*tasks, return_exceptions=True)

        result_map = {res['ip']: res for res in check_results if isinstance(res, dict) and 'ip' in res}
        for device in all_devices_for_report:
            ip = device['ip']
            if ip in result_map:
                result = result_map.get(ip, {'status': 'FAIL', 'detail': 'Check task exception'})
                device.update(result)
                self.last_results[ip] = {
                    'status': device.get('status', 'N/A'),
                    'detail': device.get('detail', ''),
                    'last_check_ts': now_ts
                }
            
            if device.get('status') == 'N/A':
                continue

            # [更新] 為失敗的設備添加明確的日誌記錄
            if device['status'] != 'OK':
                logging.warning(f"設備檢查失敗: {device['name']} ({device['ip']}) - {device['detail']}")

            if device['status'] == 'OK':
                previous_count = self.unreachable_counts.get(ip, 0)
                if previous_count > 0 and self.notification_settings.get('send_recovery', False):
                    key = f"{device['location']}:{device['type']}"
                    self.recovered_devices_by_category.setdefault(key, []).append(f"• {device['name']} ({ip}) - 已恢復")
                if ip in self.unreachable_counts:
                    del self.unreachable_counts[ip]
            else:
                count = self.unreachable_counts.get(ip, 0) + 1
                self.unreachable_counts[ip] = count
                notify_due = count == UNREACHABLE_THRESHOLD
                if device.get('renotify_enabled') and device.get('renotify_fail_count', 0) > 0 and count > UNREACHABLE_THRESHOLD:
                    renotify_fail_count = device.get('renotify_fail_count', 0)
                    notify_due = (count - UNREACHABLE_THRESHOLD) % renotify_fail_count == 0

                if count >= UNREACHABLE_THRESHOLD and notify_due:
                    self.total_unreachable += 1
                    key = f"{device['location']}:{device['type']}"
                    message = f"• {device['name']} ({ip}) - {device['detail']} [連續 {count} 次失敗]"
                    self.unreachable_devices_by_category.setdefault(key, []).append(message)
                    for channel in device.get('notification_channels', ['telegram']):
                        self.channel_notification_messages.setdefault(channel, []).append(f"[{device['location']} / {device['type']}] {message}")

        self.device_results = all_devices_for_report
        self._save_unreachable_counts()
        self._save_runtime_state()

    def prepare_report_data(self) -> Dict[str, Any]:
        """準備報告所需的資料字典"""
        report_data = {
            'script_version': SCRIPT_VERSION,
            'update_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'total_devices': 0, 'ok_devices': 0, 'fail_devices': 0,
            'locations_data': {},
            'icons': { 
                'location_ok': ICON_LOCATION_OK, 'location_fail': ICON_LOCATION_FAIL, 
                'monitoring': ICON_CATEGORY_MONITORING, 'arrow_right': ICON_ARROW_RIGHT, 
                'arrow_down': ICON_ARROW_DOWN 
            }
        }
        for result in self.device_results:
            loc, cat = result['location'], result['type']
            if loc not in report_data['locations_data']:
                report_data['locations_data'][loc] = {'categories': {}, 'status': 'ok'}
            if cat not in report_data['locations_data'][loc]['categories']:
                report_data['locations_data'][loc]['categories'][cat] = {'devices': [], 'ok': 0, 'fail': 0}

            report_data['locations_data'][loc]['categories'][cat]['devices'].append(result)
            report_data['total_devices'] += 1
            if result.get('status') == 'OK':
                report_data['ok_devices'] += 1
                report_data['locations_data'][loc]['categories'][cat]['ok'] += 1
            elif result.get('status') == 'N/A':
                pass
            else:
                report_data['fail_devices'] += 1
                report_data['locations_data'][loc]['categories'][cat]['fail'] += 1
                report_data['locations_data'][loc]['status'] = 'fail'

        def sort_key(item):
            name = item[0]
            if re.match(r'^[0-9]', name): return (1, name)
            if re.match(r'^[A-Za-z]', name): return (2, name)
            return (0, name)

        sorted_locations = sorted(report_data['locations_data'].items(), key=sort_key)
        has_fail = [item for item in sorted_locations if item[1]['status'] == 'fail']
        ok_locs = [item for item in sorted_locations if item[1]['status'] == 'ok']
        report_data['sorted_locations'] = has_fail + ok_locs
        return report_data

    def render_and_save_report(self, report_data: Dict[str, Any], system_resources: Dict[str, Any]):
        """渲染並儲存 HTML 報告"""
        logging.info("開始生成 HTML 報告...")
        try:
            # 假設模板位於與 monitor.py 同級的 templates 目錄
            template_path = BASE_DIR / 'templates' / 'report.html'
            if not template_path.exists():
                logging.error(f"找不到模板檔案: {template_path}")
                return

            template_str = template_path.read_text(encoding='utf-8')

            env = Environment(loader=BaseLoader())
            template = env.from_string(template_str)

            # [修正] 為獨立執行模式提供一個虛設的 url_for 函式
            def dummy_url_for(endpoint, **values):
                return "#" if endpoint == 'config' else '#'

            html_content = template.render(
                report=report_data, 
                system_resources=system_resources,
                get_category_icon=get_category_icon,
                url_for=dummy_url_for
            )
            HTML_REPORT_PATH.write_text(html_content, encoding='utf-8')
            if GIT_REPO_HTML_PATH.parent.exists():
                subprocess.run(['cp', str(HTML_REPORT_PATH), str(GIT_REPO_HTML_PATH)], check=True)
            logging.info(f"HTML 報告已儲存。")
        except Exception as e:
            logging.error(f"寫入 HTML 報告失敗: {e}", exc_info=True)

    def get_embedded_template(self) -> str:
        # 在此處回傳一個基礎的 HTML 模板字串作為備用
        return "<h1>Monitoring Report</h1><p>Template file not found.</p>"

    def _is_channel_cooldown(self, channel: str, cooldown_seconds: int) -> bool:
        if cooldown_seconds <= 0:
            return False
        now_ts = int(time.time())
        last_sent_ts = int(self.notification_state.get(channel, {}).get('last_sent_ts', 0))
        return (now_ts - last_sent_ts) < cooldown_seconds

    def _mark_channel_sent(self, channel: str):
        now_ts = int(time.time())
        state = self.notification_state.get(channel, {})
        state['last_sent_ts'] = now_ts
        self.notification_state[channel] = state
        self._save_runtime_state()

    def send_telegram_notification(self):
        telegram_cfg = self.notification_settings.get('channels', {}).get('telegram', {})
        if not self.notification_settings.get('enabled', True) or not telegram_cfg.get('enabled', False):
            return
        messages = self.channel_notification_messages.get('telegram', [])
        if not messages and not self.recovered_devices_by_category:
            return

        cooldown_seconds = int(self.notification_settings.get('cooldown_minutes', 30)) * 60
        if self._is_channel_cooldown('telegram', cooldown_seconds):
            logging.info("Telegram 通知仍在冷卻時間內，略過。")
            return

        token = telegram_cfg.get('token') or TELEGRAM_TOKEN
        chat_ids = telegram_cfg.get('chat_ids', [])
        if isinstance(chat_ids, str):
            chat_ids = [chat_ids]
        if not token or not chat_ids:
            return

        logging.info("正在準備發送 Telegram 異常通知...")
        message_parts = [f"🚨 <b>網路設備異常警告</b>", f"📅 <b>時間：</b>{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"]
        if messages:
            message_parts.append("📡 <b>異常設備列表：</b>")
            message_parts.extend(messages)
        if self.recovered_devices_by_category:
            message_parts.append("✅ <b>恢復設備：</b>")
            for key in sorted(self.recovered_devices_by_category.keys()):
                for msg in self.recovered_devices_by_category[key]:
                    message_parts.append(f"[{key}] {msg}")

        send_ok = True
        for chat_id in chat_ids:
            try:
                requests.post(
                    f"https://api.telegram.org/bot{token}/sendMessage",
                    data={'chat_id': chat_id, 'text': "\n".join(message_parts), 'parse_mode': 'HTML'},
                    timeout=30
                ).raise_for_status()
            except requests.exceptions.RequestException as e:
                send_ok = False
                logging.error(f"發送 Telegram 通知失敗 ({chat_id}): {e}")
        if send_ok:
            self._mark_channel_sent('telegram')
            logging.info("Telegram 通知發送完成。")

    def send_email_notification(self):
        email_cfg = self.notification_settings.get('channels', {}).get('email', {})
        if not self.notification_settings.get('enabled', True) or not email_cfg.get('enabled', False):
            return
        messages = self.channel_notification_messages.get('email', [])
        if not messages and not self.recovered_devices_by_category:
            return

        cooldown_seconds = int(self.notification_settings.get('cooldown_minutes', 30)) * 60
        if self._is_channel_cooldown('email', cooldown_seconds):
            logging.info("Email 通知仍在冷卻時間內，略過。")
            return

        to_addresses = email_cfg.get('to', [])
        if isinstance(to_addresses, str):
            to_addresses = [to_addresses]
        if not email_cfg.get('smtp_host') or not to_addresses:
            return

        subject_prefix = email_cfg.get('subject_prefix', '[GuardianOne]')
        msg = EmailMessage()
        msg['Subject'] = f"{subject_prefix} 網路設備異常通知"
        msg['From'] = email_cfg.get('from') or email_cfg.get('username')
        msg['To'] = ", ".join(to_addresses)

        content_lines = [
            "Guardian One 通知",
            f"時間: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            ""
        ]
        if messages:
            content_lines.append("異常設備列表:")
            content_lines.extend(messages)
        if self.recovered_devices_by_category:
            content_lines.append("")
            content_lines.append("恢復設備:")
            for key in sorted(self.recovered_devices_by_category.keys()):
                for item in self.recovered_devices_by_category[key]:
                    content_lines.append(f"[{key}] {item}")
        msg.set_content("\n".join(content_lines))

        try:
            smtp_host = email_cfg.get('smtp_host')
            smtp_port = int(email_cfg.get('smtp_port', 587))
            username = email_cfg.get('username')
            password = email_cfg.get('password')
            use_tls = bool(email_cfg.get('use_tls', True))

            with smtplib.SMTP(smtp_host, smtp_port, timeout=30) as server:
                if use_tls:
                    server.starttls()
                if username and password:
                    server.login(username, password)
                server.send_message(msg)
            self._mark_channel_sent('email')
            logging.info("Email 通知發送完成。")
        except Exception as e:
            logging.error(f"發送 Email 通知失敗: {e}")

    def dispatch_notifications(self):
        self.send_telegram_notification()
        self.send_email_notification()

    def run_git_push(self):
        if not GIT_PUSH_SCRIPT_PATH.is_file(): return
        logging.info("嘗試執行 Git 自動上傳腳本...")
        try:
            subprocess.run(['sudo', '-u', 'dylan', str(GIT_PUSH_SCRIPT_PATH)], capture_output=True, text=True, check=True)
            logging.info("Git 自動上傳腳本執行成功。")
        except subprocess.CalledProcessError as e:
            logging.error(f"Git 自動上傳腳本執行失敗 (Code: {e.returncode}): {e.stderr}")

async def main_runner():
    """獨立執行時的主程序"""
    setup_logging()
    start_time = datetime.now()
    logging.info(f"===== 網路設備健康檢查開始 (v{SCRIPT_VERSION}) =====")
    check_prerequisites()
    monitor = HealthMonitor()
    system_resources = monitor.get_system_resources()
    await monitor.process_all_checks()
    report_data = monitor.prepare_report_data()
    monitor.render_and_save_report(report_data, system_resources)
    monitor.dispatch_notifications()
    if os.geteuid() == 0:
        monitor.run_git_push()
    elapsed = (datetime.now() - start_time).total_seconds()
    logging.info(f"報告完成，總耗時 {elapsed:.2f} 秒。")
    logging.info("===== 網路設備健康檢查結束 =====\n")

if __name__ == "__main__":
    asyncio.run(main_runner())
