#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Scan Worker – Phase 1.3.1 (Integrated & Permissions Optimized)
Author: Dylan
Last Modified: 2026-03-13

Changelog
- v1.3.1
  * 強化 run_nmap_chunk：自動處理 --privileged 參數與 Capability 權限。
  * 修正目標傳遞邏輯，改用暫存檔避免指令列過長。
  * 增加對 nmap 指令執行路徑的完整偵測。
"""

import os
import re
import json
import time
import shutil
import socket
import ipaddress
import threading
import subprocess
from datetime import datetime
from pathlib import Path

# 專案路徑與目錄初始化
BASE_DIR = Path(__file__).resolve().parent
SCAN_DIR = BASE_DIR / "scan_jobs"
SCAN_DIR.mkdir(exist_ok=True, parents=True)

# 檔案路徑
AP_YAML = BASE_DIR / "ap_list.yaml"
SCAN_YAML = BASE_DIR / "scan_config.yaml"

# 讀取環境變數
from dotenv import load_dotenv
load_dotenv(BASE_DIR / ".env")

DEFAULT_PROFILE = os.getenv("SCAN_DEFAULT_PROFILE", "light")
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

# 本機子網環境變數（備援）
HOST_ADDR = os.getenv("HOST_ADDR")
HOST_NETMASK = os.getenv("HOST_NETMASK")

# 狀態檔
ALERT_STATE_FILE = SCAN_DIR / ".alert_state.json"

# RFC1918 私有網段
PRIVATE_NETS = [
    ("10.0.0.0", 8),
    ("172.16.0.0", 12),
    ("192.168.0.0", 16),
]

# 依賴檢查
try:
    import yaml
except ImportError:
    print("請先安裝 PyYAML：pip install pyyaml")
    sys.exit(1)

# -------------------- 工具函式 --------------------
def is_valid_ipv4(ip: str) -> bool:
    try:
        socket.inet_aton(str(ip).strip())
        return True
    except OSError:
        return False

def ip_in_private(ip: str) -> bool:
    if not is_valid_ipv4(ip): return False
    ip_int = int.from_bytes(socket.inet_aton(ip), 'big')
    for net, cidr in PRIVATE_NETS:
        net_int = int.from_bytes(socket.inet_aton(net), 'big')
        mask = (0xFFFFFFFF << (32 - cidr)) & 0xFFFFFFFF
        if (ip_int & mask) == (net_int & mask):
            return True
    return False

def cidr_is_private(cidr: str) -> bool:
    try:
        net = ipaddress.ip_network(cidr, strict=False)
        return any(net.overlaps(ipaddress.ip_network(p[0] + '/' + str(p[1]))) for p in PRIVATE_NETS)
    except Exception:
        return False

def iter_hosts_from_cidr(cidr: str, max_hosts: int) -> list:
    try:
        net = ipaddress.ip_network(cidr, strict=False)
        return [str(ip) for i, ip in enumerate(net.hosts()) if i < max_hosts]
    except Exception:
        return []

def load_yaml(path: Path):
    return yaml.safe_load(path.read_text(encoding="utf-8")) if path.exists() else {}

def detect_host_cidr() -> str | None:
    try:
        r = subprocess.run(["ip", "-4", "route", "show", "default"], stdout=subprocess.PIPE, text=True)
        m = re.search(r"\bdev\s+(\S+)", r.stdout or "")
        iface = m.group(1) if m else None
        if not iface: return None
        r2 = subprocess.run(["ip", "-4", "addr", "show", "dev", iface], stdout=subprocess.PIPE, text=True)
        m2 = re.search(r"\binet\s+([0-9.]+\/\d+)\b", r2.stdout or "")
        return m2.group(1) if m2 else None
    except Exception:
        return None

# -------------------- nmap 執行與解析 (核心修改點) --------------------
def run_nmap_chunk(targets: list, profile: dict, out_path: Path):
    """執行 nmap 並處理權限與目標清單"""
    nmap_path = "/usr/bin/nmap"
    if not nmap_path:
        return 127, "Error: nmap not found"

    # 建立臨時目標檔案 (解決指令列過長問題)
    target_file = out_path.with_suffix(".targets")
    target_file.write_text("\n".join(targets), encoding="utf-8")

    # 基本指令組
    args = [nmap_path, "-oG", str(out_path), "-iL", str(target_file)]
    
    # 加入 Profile 參數
    profile_args = profile.get("args", [])
    args += profile_args

    # 權限處理：如果參數包含 -sS (SYN) 或已手動設定過 setcap，則加入 --privileged
    # 這是解決 "requires root privileges" 報錯的關鍵
    has_privileged_arg = any(arg in profile_args for arg in ["-sS", "-sO", "-sU", "-O"])
    if has_privileged_arg:
        args.insert(1, "--privileged")

    top_ports = profile.get("top_ports")
    if top_ports:
        args += ["--top-ports", str(top_ports)]

    try:
        proc = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=600)
        return proc.returncode, proc.stdout
    except Exception as e:
        return 1, f"Execution failed: {e}"
    finally:
        if target_file.exists():
            target_file.unlink()

def parse_greppable_line(line: str):
    m = re.search(r"Ports: (.*)", line)
    if not m: return []
    results = []
    for part in m.group(1).split(','):
        try:
            p_info = part.strip().split('/')
            if p_info[1] == 'open':
                results.append({"port": int(p_info[0]), "proto": p_info[2]})
        except: continue
    return results

# -------------------- Job 執行器與其餘邏輯 --------------------
class JobState:
    def __init__(self, job_id, profile, targets):
        self.job_id = job_id
        self.profile = profile
        self.targets = targets
        self.state = "queued"
        self.started_at = None
        self.finished_at = None
        self.progress_done = 0
        self.progress_total = len(targets)
        self.summary = {"hosts": len(targets), "duration_sec": 0, "open_ports": 0}
        self.dir = SCAN_DIR / job_id
        self.dir.mkdir(parents=True, exist_ok=True)
        self._persist()

    def _persist(self):
        (self.dir / "status.json").write_text(json.dumps({
            "job_id": self.job_id, "state": self.state, "profile": self.profile,
            "progress": {"done": self.progress_done, "total": self.progress_total},
            "started_at": self.started_at, "finished_at": self.finished_at, "summary": self.summary
        }, ensure_ascii=False, indent=2))

    def set_state(self, state):
        self.state = state
        now = datetime.utcnow().isoformat() + "Z"
        if state == "running": self.started_at = now
        if state in ("succeeded", "failed"): self.finished_at = now
        self._persist()

class ScanManager:
    def __init__(self):
        self.jobs = {}

    def start_scan(self, profile_name=None, mode="yaml_list", cidr=None, deny_ips_override=None, ack_risk=False):
        cfg = load_yaml(SCAN_YAML)
        profile_name = profile_name or DEFAULT_PROFILE
        profile = cfg.get("scan_profiles", {}).get(profile_name, {})
        max_hosts = cfg.get("limits", {}).get("max_hosts_per_job", 256)

        # 目標收集邏輯
        targets = []
        if mode == "cidr" and ack_risk and cidr:
            targets = [ip for ip in iter_hosts_from_cidr(cidr, max_hosts) if ip_in_private(ip)]
        elif mode == "host_subnet":
            cidr_auto = detect_host_cidr()
            if cidr_auto: targets = [ip for ip in iter_hosts_from_cidr(cidr_auto, max_hosts) if ip_in_private(ip)]
        else:
            # 預設從 ap_list.yaml 讀取 (簡化邏輯)
            targets = self._collect_from_yaml(max_hosts)

        job_id = datetime.now().strftime("SCAN-%Y%m%d-%H%M%S")
        job = JobState(job_id, profile_name, targets)
        threading.Thread(target=self._run_job, args=(job, profile, cfg), daemon=True).start()
        return job_id

    def _collect_from_yaml(self, max_hosts):
        cfg = load_yaml(AP_YAML)
        ips = []
        for _, cats in cfg.get("locations", {}).items():
            if not isinstance(cats, dict): continue
            for _, devs in cats.items():
                for d in devs:
                    ip = d.get("ip")
                    if ip and ip_in_private(ip) and ip not in ips:
                        ips.append(ip)
                        if len(ips) >= max_hosts: return ips
        return ips

    def _run_job(self, job, profile, cfg):
        job.set_state("running")
        start_ts = time.time()
        all_results = []
        
        # 分塊執行 (Chunking)
        hgs = cfg.get("limits", {}).get("host_group_size", 32)
        chunks = [job.targets[i:i + hgs] for i in range(0, len(job.targets), hgs)]

        for idx, chunk in enumerate(chunks, 1):
            out_file = job.dir / f"chunk_{idx:02d}.greppable"
            rc, out = run_nmap_chunk(chunk, profile, out_file)
            
            if rc != 0 and not out_file.exists():
                (job.dir / "error.log").write_text(f"Nmap failed: {out}", encoding="utf-8")
                job.set_state("failed")
                return

            if out_file.exists():
                content = out_file.read_text(encoding="utf-8")
                for line in content.splitlines():
                    if "Host:" in line:
                        ip = re.search(r"Host:\s+([0-9.]+)", line).group(1)
                        ports = parse_greppable_line(line)
                        if ports:
                            all_results.append({"ip": ip, "ports": [p['port'] for p in ports]})
            
            job.progress_done += len(chunk)
            job._persist()

        (job.dir / "results.json").write_text(json.dumps(all_results, indent=2))
        job.summary["open_ports"] = sum(len(r["ports"]) for r in all_results)
        job.summary["duration_sec"] = int(time.time() - start_ts)
        job.set_state("succeeded")

    def get_status(self, job_id):
        p = SCAN_DIR / job_id / "status.json"
        return json.loads(p.read_text()) if p.exists() else None

    def get_results(self, job_id, mode="summary"):
        p = SCAN_DIR / job_id / "results.json"
        return json.loads(p.read_text()) if p.exists() else None

manager = ScanManager()
