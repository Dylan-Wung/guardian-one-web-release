#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ===============================================================
# Guardian One Web App - v5.0 (Integrated Scan API)
# Author: Dylan
# Last Modified: 2026-03-13
# ---------------------------------------------------------------
# ✅ 方案 B：封裝 Git 推送邏輯到 monitor.run_git_push()
# ✅ 保持 Git 狀態檢查簡潔，提升可維護性
# ✅ 補回 v4.7.1 掃描路由與 scan_worker 整合
# ===============================================================

import sys
import os
import asyncio
import logging
import threading
import time
import json
from pathlib import Path
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import yaml
import subprocess

# --- 核心整合：直接導入本機的監控模組 ---
try:
    from monitor import (
        HealthMonitor, setup_logging, check_prerequisites,
        YAML_CONFIG_FILE, get_category_icon, SCRIPT_VERSION as MONITOR_VERSION,
        ICON_LOCATION_OK, ICON_LOCATION_FAIL, ICON_CATEGORY_MONITORING,
        ICON_ARROW_RIGHT, ICON_ARROW_DOWN, BASE_DIR,
        GIT_REPO_HTML_PATH, load_notification_settings,
        save_notification_settings, LAST_RESULTS_FILE
    )
except ImportError:
    print("錯誤：無法從 monitor 導入必要模組。請確認 monitor.py 是否正確。")
    sys.exit(1)

# --- 導入掃描工作模組 (補回) ---
try:
    from scan_worker import manager
except ImportError as e:
    manager = None
    logging.warning(f"無法載入 scan_worker: {e}。掃描功能將被停用。")

# 初始化
setup_logging()
check_prerequisites()

app = Flask(__name__)
app.secret_key = os.urandom(24)
TEMPLATE_YAML_CONFIG_FILE = BASE_DIR / "template_ap_list.yaml"

# 全域變數預設值
latest_results = {
    "report_data": {
        'script_version': MONITOR_VERSION,
        'update_time': '等待首次監控完成...',
        'total_devices': 0, 'ok_devices': 0, 'fail_devices': 0,
        'sorted_locations': [],
        'icons': {
            'location_ok': ICON_LOCATION_OK,
            'location_fail': ICON_LOCATION_FAIL,
            'monitoring': ICON_CATEGORY_MONITORING,
            'arrow_right': ICON_ARROW_RIGHT,
            'arrow_down': ICON_ARROW_DOWN
        }
    },
    "system_resources": {
        "cpu": {"usage": 0, "status_text": "N/A", "class": "ok", "warn": 70, "error": 90},
        "mem": {"usage": 0, "status_text": "N/A", "class": "ok", "warn": 70, "error": 90},
        "disk": {"usage": 0, "status_text": "N/A", "class": "ok", "warn": 80, "error": 90},
        "load_avg": 0
    }
}

monitor_control = {
    "force_run": threading.Event(),
    "stop": threading.Event(),
    "lock": threading.Lock(),
    "runner_thread": None
}

# 🔄 Git 狀態檢查並推送（方案 B）
def push_if_git_changed(monitor: HealthMonitor):
    if os.geteuid() != 0:
        logging.warning("非 root 權限，跳過 Git 狀態檢查與推送。")
        return
    try:
        result = subprocess.run(['git', 'diff', '--quiet'], cwd=GIT_REPO_HTML_PATH.parent)
        if result.returncode != 0:
            logging.info("Git 狀態有變更，執行推送...")
            monitor.run_git_push()
        else:
            logging.info("Git 狀態無變更，跳過推送。")
    except Exception as e:
        logging.error(f"Git 狀態檢查失敗：{e}")

# 背景監控任務
def run_monitoring_job():
    if not monitor_control["lock"].acquire(blocking=False):
        logging.info("背景監控任務仍在執行中，略過本次觸發。")
        return
    logging.info("✅ 背景監控任務啟動")
    try:
        monitor = HealthMonitor()
        system_resources = monitor.get_system_resources()

        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(monitor.process_all_checks())
        loop.close()

        report_data = monitor.prepare_report_data()

        monitor.dispatch_notifications()
        monitor.render_and_save_report(report_data, system_resources)
        push_if_git_changed(monitor)

        global latest_results
        latest_results = {
            "report_data": report_data,
            "system_resources": system_resources
        }

        logging.info("✅ 背景監控任務完成")
    except Exception as e:
        logging.error(f"❌ 背景任務發生錯誤: {e}", exc_info=True)
    finally:
        monitor_control["lock"].release()


def monitoring_loop():
    """Uptime Kuma 風格：常駐輪詢控制器。"""
    logging.info("🧭 監控控制器已啟動（每秒輪詢是否需要執行檢查）")
    while not monitor_control["stop"].is_set():
        should_run = has_due_devices() or monitor_control["force_run"].is_set()
        if monitor_control["force_run"].is_set():
            monitor_control["force_run"].clear()
        if should_run:
            run_monitoring_job()
        monitor_control["force_run"].wait(timeout=1)
    logging.info("🛑 監控控制器已停止")


def trigger_monitoring_run():
    monitor_control["force_run"].set()


def has_due_devices() -> bool:
    try:
        config = yaml.safe_load(YAML_CONFIG_FILE.read_text(encoding='utf-8')) or {}
        if LAST_RESULTS_FILE.exists():
            last_results = json.loads(LAST_RESULTS_FILE.read_text(encoding='utf-8'))
        else:
            last_results = {}

        now_ts = int(time.time())
        for _, types in config.get('locations', {}).items():
            for _, devices in types.items():
                if not isinstance(devices, list):
                    continue
                for device in devices:
                    ip = device.get('ip')
                    if not ip:
                        continue
                    interval = max(5, int(device.get('interval_seconds', 300)))
                    last_check_ts = int(last_results.get(ip, {}).get('last_check_ts', 0))
                    if now_ts - last_check_ts >= interval:
                        return True
    except Exception as e:
        logging.warning(f"檢查設備到期狀態失敗，改為觸發檢查: {e}")
        return True
    return False

# --- Routes ---

@app.route('/')
def report():
    return render_template('report.html',
                           report=latest_results["report_data"],
                           system_resources=latest_results["system_resources"],
                           get_category_icon=get_category_icon)

@app.route('/config', methods=['GET', 'POST'])
def config():
    if request.method == 'POST':
        content = request.form['content']
        try:
            yaml.safe_load(content)
            with open(YAML_CONFIG_FILE, 'w', encoding='utf-8') as f:
                f.write(content)
            flash('設定檔儲存成功，已觸發更新。', 'success')
            trigger_monitoring_run()
        except yaml.YAMLError as e:
            flash(f'YAML 格式錯誤：{e}', 'error')
        except IOError as e:
            flash(f'寫入設定失敗: {e}', 'error')
        return redirect(url_for('config'))

    try:
        raw_content = YAML_CONFIG_FILE.read_text(encoding='utf-8')
        initial_data = yaml.safe_load(raw_content)
    except Exception as e:
        raw_content = f"# 讀取設定檔失敗: {e}"
        initial_data = {}
        flash(f'讀取失敗: {e}', 'error')

    template_data = {}
    try:
        if TEMPLATE_YAML_CONFIG_FILE.exists():
            template_data = yaml.safe_load(TEMPLATE_YAML_CONFIG_FILE.read_text(encoding='utf-8'))
        else:
            flash('⚠ 無法找到設定範本 template_ap_list.yaml', 'warning')
    except Exception as e:
        flash(f'範本讀取失敗: {e}', 'error')

    return render_template('config.html',
                           content=raw_content,
                           initial_data=initial_data,
                           template_data=template_data)


@app.route('/notifications', methods=['GET', 'POST'])
def notifications():
    def parse_lines(text: str):
        return [line.strip() for line in text.splitlines() if line.strip()]

    if request.method == 'POST':
        try:
            if 'content' in request.form:
                content = request.form['content']
                settings = yaml.safe_load(content)
                if not isinstance(settings, dict):
                    raise yaml.YAMLError('通知設定必須為 YAML 物件')
            else:
                settings = {
                    'enabled': request.form.get('enabled') == 'on',
                    'cooldown_minutes': int(request.form.get('cooldown_minutes', '30')),
                    'send_recovery': request.form.get('send_recovery') == 'on',
                    'channels': {
                        'telegram': {
                            'enabled': request.form.get('telegram_enabled') == 'on',
                            'token': request.form.get('telegram_token', '').strip(),
                            'chat_ids': parse_lines(request.form.get('telegram_chat_ids', ''))
                        },
                        'email': {
                            'enabled': request.form.get('email_enabled') == 'on',
                            'smtp_host': request.form.get('smtp_host', '').strip(),
                            'smtp_port': int(request.form.get('smtp_port', '587')),
                            'use_tls': request.form.get('use_tls') == 'on',
                            'username': request.form.get('email_username', '').strip(),
                            'password': request.form.get('email_password', ''),
                            'from': request.form.get('email_from', '').strip(),
                            'to': parse_lines(request.form.get('email_to', '')),
                            'subject_prefix': request.form.get('subject_prefix', '[GuardianOne]').strip()
                        }
                    }
                }

            saved_path = save_notification_settings(settings)
            flash(f'通知設定儲存成功（{saved_path}）。', 'success')
            trigger_monitoring_run()
        except yaml.YAMLError as e:
            flash(f'通知設定 YAML 格式錯誤：{e}', 'error')
        except ValueError as e:
            flash(f'通知設定數值格式錯誤：{e}', 'error')
        except IOError as e:
            flash(f'寫入通知設定失敗: {e}', 'error')
        return redirect(url_for('notifications'))

    try:
        settings = load_notification_settings()
        raw_content = yaml.safe_dump(settings, allow_unicode=True, sort_keys=False)
    except Exception as e:
        settings = load_notification_settings()
        raw_content = f"# 讀取通知設定失敗: {e}"
        flash(f'讀取通知設定失敗: {e}', 'error')

    return render_template('notifications.html', content=raw_content, settings=settings)

# --- 補回：掃描頁面與 API 路由 (移植自 v4.7.1) ---

@app.route('/scan')
def scan_page():
    return render_template('scan.html')

@app.route('/api/monitored-ips')
def api_monitored_ips():
    if manager is None:
        return jsonify({"error": "掃描服務不可用"}), 503
    try:
        with open(YAML_CONFIG_FILE, 'r', encoding='utf-8') as f:
            cfg = yaml.safe_load(f) or {}
        ips, seen = [], set()
        for _, cats in cfg.get('locations', {}).items():
            if not isinstance(cats, dict): continue
            for _, devs in cats.items():
                if not isinstance(devs, list): continue
                for d in devs:
                    ip = str(d.get('ip', '')).strip()
                    if ip and ip not in seen:
                        seen.add(ip)
                        ips.append(ip)
        return jsonify({"items": sorted(ips)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/scan', methods=['POST'])
def api_scan_create():
    if manager is None:
        return jsonify({"error": "掃描服務不可用"}), 503
    try:
        body = request.get_json(silent=True) or {}
        job_id = manager.start_scan(
            profile_name=body.get('profile'),
            mode=body.get('mode'),
            cidr=body.get('cidr'),
            deny_ips_override=body.get('deny_ips', []),
            ack_risk=bool(body.get('ack_risk', False))
        )
        return jsonify({"job_id": job_id, "state": "queued"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/api/scan/<job_id>/status')
def api_scan_status(job_id):
    if manager is None:
        return jsonify({"error": "掃描服務不可用"}), 503
    st = manager.get_status(job_id)
    if not st:
        return jsonify({"error": "任務不存在"}), 404
    return jsonify(st)

@app.route('/api/scan/<job_id>/results')
def api_scan_results(job_id):
    if manager is None:
        return jsonify({"error": "掃描服務不可用"}), 503
    fmt = request.args.get('format', 'summary')
    rs = manager.get_results(job_id, fmt)
    if not rs:
        return jsonify({"error": "任務不存在"}), 404
    return jsonify(rs)

# --- 啟動服務 ---
if __name__ == '__main__':
    logging.info("🚀 啟動 Flask Web 伺服器與監控控制器")
    monitor_control["runner_thread"] = threading.Thread(target=monitoring_loop, daemon=True)
    monitor_control["runner_thread"].start()
    app.run(host='0.0.0.0', port=5000, debug=False)
